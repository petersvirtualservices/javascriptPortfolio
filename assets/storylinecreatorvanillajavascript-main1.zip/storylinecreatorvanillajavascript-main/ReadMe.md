
# Movement Analyzer

## Description
This site is meant to allow you to upload videos and analyze movements in order to create a statistical model of action and reaction.

## Table of Contents
[Description](#Description)

[Installation Instructions](#Installation_Instructions)

[Operating Instructions](#Operating_Instructions)

[Test Environment Instruction](#Test_Environment_Instruction)

[Copyright and Licensing Information](#Copyright_and_Licensing_Information)

[Contact Information](#Contact_Information)

[Credits](#Credits)


## Installation_Instructions
Click in the index.html file.

## Operating_Instructions
Click on the index.html file and input the YouTube embed URL.  Click start and click on the buttons as the actions happen.

## Test_Environment_Instruction
Click on index.html.

## Copyright_and_Licensing_Information
MIT

## Contact_Information
Name: Charlene Peters

GitHub: petersvirtualservices

Upwork: https://www.upwork.com/freelancers/petersvirtualservices

Email: charlene@peters-services.com

## Credits
N/A
